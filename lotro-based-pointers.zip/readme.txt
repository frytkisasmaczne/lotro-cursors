﻿=== Lotro based pointers Cursor Set ===

By: nsqui5

Download: http://www.rw-designer.com/cursor-set/lotro-based-pointers

Author's decription:

A set of cursors i made based on the Lord Of The Rings Online cursor. By NS

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.